package com.cts.exception;


@SuppressWarnings("serial")
public class DrugNotFoundException extends Exception {


	public DrugNotFoundException(String message)
	{
		super(message);
	}



}
