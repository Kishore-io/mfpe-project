export interface User {
    userid: string;
    uname: string;
    upassword :string;
    //authToken !:string;
}