import { SubscriptionDetails } from './subscription-details';

describe('SubscriptionDetails', () => {
  it('should create an instance', () => {
    expect(new SubscriptionDetails()).toBeTruthy();
  });
});
