import { DrugDetails } from './drug-details';

describe('DrugDetails', () => {
  it('should create an instance', () => {
    expect(new DrugDetails()).toBeTruthy();
  });
});
