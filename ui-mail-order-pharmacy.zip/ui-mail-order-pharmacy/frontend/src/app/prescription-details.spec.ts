import { PrescriptionDetails } from './prescription-details';

describe('PrescriptionDetails', () => {
  it('should create an instance', () => {
    expect(new PrescriptionDetails()).toBeTruthy();
  });
});
