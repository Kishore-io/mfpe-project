export interface AuthenticationResponse {
    uid:string,
    name:string,
    valid:boolean
}
