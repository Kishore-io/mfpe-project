package com.cts.exception;

@SuppressWarnings("serial")
public class DrugQuantityNotAvailable extends Exception {
	
	public  DrugQuantityNotAvailable(String message) {
		super(message);
	}
	
}
